const { onRequest } = require('firebase-functions/v2/https');

const ALLOWED_HOSTS = (process.env.PROXY_ALLOWED_HOSTS || '')
  .split(',').map(x => x.trim().toLowerCase()).filter(Boolean);
const TOKEN = (process.env.PROXY_TOKEN || '').trim();

function isPrivateIPv4(host) {
  const m = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m) return false;
  const a = +m[1], b = +m[2];
  return a === 0 || a === 10 || a === 127 || a >= 224 ||
    (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
}
function hostAllowed(host) {
  const h = host.toLowerCase();
  return ALLOWED_HOSTS.some(d => h === d || h.endsWith('.' + d));
}
function checkTarget(raw) {
  let u;
  try { u = new URL(raw); } catch { throw new Error('Invalid target URL'); }
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('Only HTTP(S) streams are supported');
  if (u.username || u.password) throw new Error('Credentials in stream URLs are not allowed');
  const h = u.hostname.toLowerCase();
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') ||
      h === 'metadata.google.internal' || h === 'metadata.google') throw new Error('Private/local host blocked');
  if (isPrivateIPv4(h) || h.includes(':')) throw new Error('IP literal/private host blocked; use an allowlisted hostname');
  if (!ALLOWED_HOSTS.length) throw new Error('Set PROXY_ALLOWED_HOSTS in functions/.env before deploying');
  if (!hostAllowed(h)) throw new Error('Host is not in PROXY_ALLOWED_HOSTS: ' + h);
  return u;
}
function proxyUrl(base, target) { return base + '?url=' + encodeURIComponent(target) + (TOKEN ? '&token=' + encodeURIComponent(TOKEN) : ''); }
function rewriteManifest(text, sourceUrl, base) {
  return text.split(/\r?\n/).map(line => {
    const trimmed = line.trim();
    if (!trimmed) return line;
    if (trimmed.startsWith('#')) {
      return line.replace(/URI="([^"]+)"/g, (_, uri) => `URI="${proxyUrl(base, new URL(uri, sourceUrl).href)}"`);
    }
    try { return proxyUrl(base, new URL(trimmed, sourceUrl).href); } catch { return line; }
  }).join('\n');
}

exports.streamProxy = onRequest({
  cors: true,
  timeoutSeconds: 120,
  memory: '512MiB',
  maxInstances: 10,
  concurrency: 20
}, async (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
  res.set('Access-Control-Allow-Headers', 'Range, Content-Type, Accept');
  res.set('Access-Control-Expose-Headers', 'Content-Length, Content-Range, Accept-Ranges');
  res.set('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (!['GET', 'HEAD'].includes(req.method)) return res.status(405).send('Method not allowed');
  if (TOKEN && req.query.token !== TOKEN) return res.status(401).send('Proxy token required');
  const raw = typeof req.query.url === 'string' ? req.query.url : '';
  if (!raw) return res.status(400).send('Missing ?url= target');
  let target;
  try { target = checkTarget(raw); } catch (e) { return res.status(400).send(e.message); }
  try {
    const headers = { 'User-Agent': 'SanTV-Authorized-Stream-Proxy/1.0', 'Accept': req.get('accept') || '*/*' };
    const range = req.get('range'); if (range) headers.Range = range;
    const upstream = await fetch(target.href, { method: req.method, headers, redirect: 'follow', signal: AbortSignal.timeout(110000) });
    const finalUrl = new URL(upstream.url || target.href);
    // Validate redirects too, to reduce SSRF and allowlist bypass risk.
    checkTarget(finalUrl.href);
    res.status(upstream.status);
    for (const h of ['content-type', 'content-length', 'content-range', 'accept-ranges', 'last-modified', 'etag']) {
      const v = upstream.headers.get(h); if (v) res.set(h, v);
    }
    const type = (upstream.headers.get('content-type') || '').toLowerCase();
    const looksManifest = /\.m3u8?(?:$|\?)/i.test(finalUrl.href) || type.includes('mpegurl') || type.includes('vnd.apple.mpegurl');
    if (looksManifest && req.method !== 'HEAD') {
      const body = await upstream.text();
      const base = req.protocol + '://' + req.get('host') + req.path;
      res.set('Content-Type', 'application/vnd.apple.mpegurl; charset=utf-8');
      return res.send(rewriteManifest(body, finalUrl.href, base));
    }
    if (req.method === 'HEAD') return res.end();
    const buf = Buffer.from(await upstream.arrayBuffer());
    return res.send(buf);
  } catch (e) {
    return res.status(502).send('Upstream fetch failed: ' + (e && e.message ? e.message : 'unknown error'));
  }
});
