# SanTV Firebase Proxy + Hosting

This bundle provides a Firebase Hosting copy of the dashboard and an HTTPS Function that proxies authorized HLS/HTTP streams and rewrites HLS manifest segment/key URLs through the same function.

## Important limits
- This is not a universal bypass. It cannot defeat DRM, authentication, geo-blocks, expired tokens, dead streams, or upstream restrictions. HLS and CORS behaviour varies by provider/player.
- Firebase Functions deployment generally requires a Firebase project with billing enabled (Blaze plan) and the Firebase CLI.
- Set an explicit hostname allowlist. Do not deploy as an unrestricted public proxy. Only include hostnames for streams you own or are authorized to access.
- A client-side token is visible in the page and is not a substitute for real authentication; use host allowlisting and suitable quotas.

## Deploy
1. Install Node.js 20+ and Firebase CLI: `npm install -g firebase-tools`
2. Run `firebase login`.
3. Copy `.firebaserc.example` to `.firebaserc` and replace `YOUR_FIREBASE_PROJECT_ID` with your project ID, or run `firebase use --add`.
4. Copy `functions/.env.example` to `functions/.env` and set `PROXY_ALLOWED_HOSTS` to comma-separated hostnames used by your authorized playlist/segment/CDN URLs. Example: `PROXY_ALLOWED_HOSTS=tv.example.com,cdn.example.net`.
5. Run `npm --prefix functions install`.
6. Deploy: `firebase deploy --only functions:streamProxy,hosting`.
7. In Firebase Console, open Functions and copy the `streamProxy` HTTPS URL. It resembles `https://REGION-PROJECT_ID.cloudfunctions.net/streamProxy`.
8. In SanTV Dashboard Settings → Proxy (Firebase / Worker), paste the URL with `?url=` appended, for example `https://REGION-PROJECT_ID.cloudfunctions.net/streamProxy?url=`. Save, enable the proxy, and Test.

## Notes
- The function requires `?url=https%3A%2F%2F...` and checks the hostname against `PROXY_ALLOWED_HOSTS`.
- HLS manifest URLs (segments, child playlists, and URI attributes such as AES keys) are rewritten. Other formats are streamed as bytes with Range support where upstream supports it.
- This bundle was syntax-checked locally only; deploy and test with your Firebase project and actual authorized streams before relying on it.
